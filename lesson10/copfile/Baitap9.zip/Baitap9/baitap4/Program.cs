﻿StudentManager sList= new StudentManager(new Dictionary<int, Student>());
int choosen;
string name;
double mark;
int age;
int id;
int updatePersonByID;
int deletePersonByID;
int checkUpdate;
int checkDelete;
string searchPersonByName;
int checkSearch;

do{
    Menu();
    choosen=Convert.ToInt32(Console.ReadLine());
    while(choosen <0 || choosen >5){
        Console.WriteLine("Invalid choosen! Please choose from 0 to 5 !");
        choosen=Convert.ToInt32(Console.ReadLine());
    }
    switch(choosen){
        case 1:
        Console.WriteLine("ADD STUDENT: ");
        id=Convert.ToInt32(Console.ReadLine());
        name=Console.ReadLine() ?? "";
        age=Convert.ToInt32(Console.ReadLine());
        mark=Convert.ToDouble(Console.ReadLine());
        sList.AddStudent(id, name, age, mark);
        Console.WriteLine("ADD COMPLETE !");
        Console.ReadKey();
        break;
        case 2:
        Console.WriteLine("UPDATE STUDENT: ");
        Console.Write("Input the person ID: ");
        updatePersonByID=Convert.ToInt32(Console.ReadLine());
        checkUpdate=sList.UpdateStudent(updatePersonByID);
        if(checkUpdate==1)Console.WriteLine("Update Complete !");
        else Console.WriteLine("Update false !");
        Console.ReadKey();
        break;
        case 3:
         Console.WriteLine("DELETE STUDENT: ");
         Console.Write("Input the person ID: ");
         deletePersonByID=Convert.ToInt32(Console.ReadLine());
         checkDelete=sList.DeleteStudent(deletePersonByID);
         if(checkDelete==1)Console.WriteLine("Delete Complete !");
         else Console.WriteLine("Delete false !");
         Console.ReadKey();
         break;
         case 4:
         Console.WriteLine("SEARCH STUDENT: ");
         Console.Write("Input the person name: ");
         searchPersonByName=Console.ReadLine() ?? "";
         checkSearch=sList.SearchStudent(searchPersonByName);
         if(checkSearch==1)Console.WriteLine("Search Complete !");
         else Console.WriteLine("Search false !");
         Console.ReadKey();
         break;
         case 5:
         Console.WriteLine("DISPLAY ALL STUDENT: ");
         sList.DisplayAllStudent();
         Console.WriteLine("Display complete !");
         Console.ReadKey();
         break;
         case 0:
         Console.WriteLine("EXIT APPLICATION !");
         break;
    }

}while(choosen !=0);

static void Menu(){
    Console.Write("MENU \n-----------------------------------\n 1. Add Students \n 2. Update a Student \n 3. Delete a Student \n 4. Search Students \n 5. Display All Students \n 0. Exit \n----------------------------------- \nYour choice:");
    
}

