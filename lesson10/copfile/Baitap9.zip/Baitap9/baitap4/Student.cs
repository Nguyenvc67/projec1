public class Student{
    public string Name{get;set;}
    public int Age{get;set;}
    public double Mark{get;set;}
    public Student(){
        this.Name="";
        this.Age=3;
        this.Mark=1;
    }
    public Student(string name, int age, double mark){
        this.Name=name;
        this.Age=age;
        this.Mark=mark;
    }
    public string FullInfomation{
        get{
            return $"Name: {this.Name} age: {this.Age} mark: {this.Mark}".Trim();
        }
    }


}