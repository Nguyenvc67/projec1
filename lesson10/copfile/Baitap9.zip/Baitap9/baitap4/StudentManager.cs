using System.Collections.Generic;
public class StudentManager{
    public Dictionary<int, Student> Contain{get;set;}
    public StudentManager(){
        this.Contain=new Dictionary<int, Student>();
    }
    public StudentManager(Dictionary<int, Student> contain){
        this.Contain=contain;
    }
    public void AddStudent(int id, string name, int age, double mark){
        Student newer = new Student(name, age, mark);
        (this.Contain).Add(id, newer);
    }
    public int UpdateStudent(int id){
        int check=0;
        foreach(var dS in this.Contain){
            if(dS.Key==id){
                check++;
                Console.Write("Change name: ");
                dS.Value.Name=Console.ReadLine() ?? "";
                Console.Write("Change age: ");
                dS.Value.Age=Convert.ToInt32(Console.ReadLine());
                Console.Write("Change mark: ");
                dS.Value.Mark=Convert.ToDouble(Console.ReadLine());
            }
        }
        if(check==0)return 0;
        else return 1;
    }
    public int DeleteStudent(int id){
        int check=0;
        foreach(var dS in this.Contain){
            if(dS.Key==id){
                check++;
                (this.Contain).Remove(dS.Key);
            }
        }
        if(check==0)return 0;
        else return 1;
    }
    public int FindPeriod(Student student,string search){
        int check=0;
        for(int i=0;i<search.Length;i++){
            for(int j=0;j<(student.Name).Length;j++){
                if(search[i]==(student.Name)[j]){
                    check++;
                    break;
                }
            }
        }
        if(check==search.Length)return 1;
        else return 0;
    }
    public int SearchStudent(string search){
        int th=1;
        int check=0;
        foreach(var dS in this.Contain){
            if(FindPeriod(dS.Value, search)==1){
                check++;
                Console.WriteLine($"{th}th Student name: {dS.Value.Name}, age: {dS.Value.Age}, mark: {dS.Value.Mark}");
                th++;
            }
        }
        if(check==0)return 0;
        else return 1;
    }
    public void DisplayAllStudent(){
        foreach(var dS in this.Contain){
            Console.WriteLine($"{dS.Key}: {dS.Value.FullInfomation}");
        }
    }
}