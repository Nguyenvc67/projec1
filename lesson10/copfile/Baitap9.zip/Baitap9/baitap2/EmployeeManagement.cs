using System.Collections;
public class EmployeeManagement{
    public ArrayList Contain{get;set;}

    public EmployeeManagement(){
        this.Contain=new ArrayList();
    }
    public EmployeeManagement(ArrayList contain){
        Contain=contain;
    }
    public void AddEmp(string name, int age, double salary){
        Employe newer=new Employe(name, age, salary);
        (this.Contain).Add(newer);
    }
    public int CheckExist(string name, int age, double salary){
        Employe check=new Employe(name, age, salary);
        foreach(Employe aE in this.Contain){
            if((aE.FullInfomation).Equals(check.FullInfomation))return 1;
        }
        return 0;
    }
    public int ModifyEmp(string name, int age, double salary){
        int checkk=0;
        Employe check=new Employe(name, age, salary);
        foreach(Employe aE in this.Contain){
            if((aE.FullInfomation).Equals(check.FullInfomation)){
                checkk++;
                Console.Write("Change name: ");
                aE.Name=Console.ReadLine();
                Console.Write("Change age: ");
                aE.Age=Convert.ToInt32(Console.ReadLine());
                Console.Write("Change salary: ");
                aE.Salary=Convert.ToDouble(Console.ReadLine());
            }
        }
        if(checkk==0)return 0;
        else{
            return 1;
        }
    }
    public int RemoveEmp(string name, int age, double salary){
        Employe check=new Employe(name, age, salary);
        foreach(Employe aE in this.Contain){
            if((aE.FullInfomation).Equals(check.FullInfomation)){
                (this.Contain).Remove(aE);
                return 1;
            }
        }
        return 0;
    }
    public void DisplayAll(){
        foreach(Employe aE in this.Contain){
            Console.WriteLine($"{aE.Name}: {aE.Age} years old, {aE.Salary} $/Month .");
        }
    }

}