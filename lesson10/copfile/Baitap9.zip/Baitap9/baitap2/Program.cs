﻿using System.Collections;
EmployeeManagement aList=new EmployeeManagement(new ArrayList());

aList.AddEmp("D", 21, 2500000000);
aList.AddEmp("C", 21, 5500000000);
aList.AddEmp("a", 20, 2500000000);
aList.AddEmp("b", 23, 2500000000);
aList.AddEmp("c", 25, 2500000000);
Console.WriteLine("Remove an Employee: C 21 5500000000");
int k=aList.RemoveEmp("C", 21, 5500000000);
aList.DisplayAll();
Console.WriteLine("Modify an Employee: D 21 25000000000");
int m=aList.ModifyEmp("D", 21, 2500000000);
aList.DisplayAll();

Console.WriteLine("Using Dictionary : ");
EMDictionary dList=new EMDictionary(new Dictionary<int, Employe>());
dList.AddEmpV2(1, "Dat", 21, 123456789);
dList.AddEmpV2(2, "Nam", 21, 123456789);
dList.DisplayAllV2();



