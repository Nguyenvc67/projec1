using System.Collections;
public class EMDictionary{
    public Dictionary<int, Employe> Contain{get;set;}

    public EMDictionary(){
        this.Contain=new Dictionary<int, Employe>();
    }
    public EMDictionary(Dictionary<int, Employe> contain){
        Contain=contain;
    }
    public void AddEmpV2(int id, string name, int age, double salary){
        Employe newer=new Employe(name, age, salary);
        (this.Contain).Add(id, newer);
    }
    public int RemoveEmpV2(int id){
        foreach(var aE in this.Contain){
            if(aE.Key==id){
                (this.Contain).Remove(aE.Key);
                return 1;
            }
        }
        return 0;
    }
    public void DisplayAllV2(){
        foreach(var dE in this.Contain){
            Console.WriteLine($"{dE.Key} {dE.Value.FullInfomation}");
        }
    }
}