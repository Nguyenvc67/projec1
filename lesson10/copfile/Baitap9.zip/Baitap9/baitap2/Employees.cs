public class Employe : IComparable{
    public string Name{get;set;}
    public int ?Age{get;set;}
    public double ?Salary{get;set;}
    public Employe(){
        this.Name="";
        this.Age=20;
        this.Salary=100000000;
    }
    public Employe(string name, int age, double salary){
        this.Name=name;
        this.Age=age;
        this.Salary=salary;
    }
    public string FullInfomation{
        get{
            return $"{Name} {Age} {Salary}".Trim();
        }
    }
    public override bool Equals(object? obj)
    {
        if(obj==null || !(obj is Employe)){
            return false;
        }
        return this.FullInfomation.Equals(((Employe)obj).FullInfomation);
    }
    public override int GetHashCode(){
        return this.FullInfomation.GetHashCode();
    }
    public int CompareTo(object? obj){
        if(obj == null|| !(obj is Employe)){
            return 0;
        }
        return this.FullInfomation.CompareTo(((Employe)obj).FullInfomation);
    }

}