﻿using System.Collections;
List<double> temperature = new List<double>();
for(int i=0;i<5;i++){
Console.Write($"{i+1}th : ");
temperature.Add(Convert.ToDouble(Console.ReadLine()));
}
Console.Write($"There are: {GreaterCount(temperature, 25)} temperature greater or equal 25 .");
static int GreaterCount(List<double> list, double min){
    int count=0;
    foreach(var aT in list){
        if(aT>=min)count++;
    }
    return count;
}
