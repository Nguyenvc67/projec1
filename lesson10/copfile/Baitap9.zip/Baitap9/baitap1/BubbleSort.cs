public class BubbleSort: System.Collections.IComparer{
    public int Compare(object? obj1, object? obj2){
        if(obj1!=null && obj2!=null && obj1 is int && obj2 is int){
            int c1=(int)obj1;
            int c2=(int)obj2;
            return c1.CompareTo(c2);
        }
        return 0;
    }
}
       