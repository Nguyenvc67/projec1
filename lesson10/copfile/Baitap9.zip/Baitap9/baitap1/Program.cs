﻿using System.Collections;

ArrayList array=new ArrayList();
for(int i=0;i<10;i++){
    Console.WriteLine($"{i+1}th element: ");
    array.Add(Convert.ToInt32(Console.ReadLine()));
}
array.Sort(new BubbleSort());
foreach(var ar in array){
    Console.WriteLine(ar);
}
