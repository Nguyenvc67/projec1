﻿// See https://aka.ms/new-console-template for more information
double centimet;
double inch;
Console.Write("Enter centimet:");
centimet = double.Parse(Console.ReadLine());
Console.Write("Enter inch:");
inch = double.Parse(Console.ReadLine());
double inch1;
inch1 = centimet*2.54;
Console.WriteLine("centimet->inch:{0} inch",inch1);
double centimet1;
centimet1 = inch/2.54;
Console.WriteLine("inch->centimet:{0} cm",centimet1);