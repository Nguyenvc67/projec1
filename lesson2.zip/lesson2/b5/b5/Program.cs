﻿// See https://aka.ms/new-console-template for more information
int h;
float luongcb;
float luong;
Console.Write("nhap so gio:");
h = int.Parse(Console.ReadLine());
Console.Write("nhap so luong co ban:");
luongcb = int.Parse(Console.ReadLine());
luong = luongcb*h;
Console.WriteLine("luong nhan vien la:{0:C}",luong);