﻿// See https://aka.ms/new-console-template for more information
Console.Write("nhap so tien:");

int i = int.Parse(Console.ReadLine());
Console.Write("tien thue cua new york:");
float thue = (i*0.0825f);

Console.WriteLine("{0:C}", thue);
