﻿// See https://aka.ms/new-console-template for more information
using System;
namespace ConsoleApplication
{
public class Program
{
public static void Main(string[] args)
{
// my first program in C#
Console.WriteLine("No");
Console.ReadLine();
Console.WriteLine("Name");
Console.ReadLine();
Console.WriteLine("Address");
Console.ReadLine();
Console.WriteLine("Phone");
Console.ReadLine();
}
}
}
