﻿// See https://aka.ms/new-console-template for more information
using System;
namespace ConsoleApplication
{
public class Program
{
public static void Main(string[] args)
{
// my first program in C#
int a,b,c;

Console.Write("a=");
a=int.Parse(Console.ReadLine());
Console.Write("b=");
b=int.Parse(Console.ReadLine());
Console.Write("c=");
c=int.Parse(Console.ReadLine());
if(a>b&&a>c)
{
    Console.WriteLine("so lon nhat a="+a);
    //else if(b>c)
    //{
    //    Console.WriteLine("so lon nhat b="+b);
    //}
    //else
    //{
    //    Console.WriteLine("so lon nhat c="+c);
    // }
}
if(b>a&&b>c)
{
    Console.WriteLine("so lon nhat b="+b);
}
if(c>a&&c>b)
{
    Console.WriteLine("so lon nhat c="+c);
}
}
}
}
