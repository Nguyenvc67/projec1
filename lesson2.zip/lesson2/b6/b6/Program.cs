﻿// See https://aka.ms/new-console-template for more information
int h;
float luongcb;
float luong;

Console.Write("nhap so gio lam trong tuan:");
h = int.Parse(Console.ReadLine());
Console.Write("nhap luong co ban:");
luongcb = int.Parse(Console.ReadLine());
luong = luongcb*h*4;
if(luongcb<5.15||h>40)
{
    Console.WriteLine("error!");
}
if(luongcb>=5.15&&h<=40)
{
    Console.WriteLine("luong nhan vien:{0:C}",luong);
}
