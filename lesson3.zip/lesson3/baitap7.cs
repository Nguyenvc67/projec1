﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string num;
        
        Console.Write("Input number of element: ");
        num=Console.ReadLine();
        int inum=Convert.ToInt32(num);
        int []array=new int[inum];
        for(int i=0;i<inum;i++){
            Console.Write($"{i+1}th element: ");
            string k=Console.ReadLine();
            array[i]=Convert.ToInt32(k);
        }
        int demchan=0;
        int demle=0;
        for(int i=0;i<inum;i++){
            if(array[i]%2==0)demchan++;
            else{
                demle++;
            }
        }
        int []arraychan=new int[demchan];
        int []arrayle=new int[demle];
        int indexchan=0;
        int indexle=0;
        for(int i=0;i<inum;i++){
            if(array[i]%2==0){
                arraychan[indexchan]=array[i];
                indexchan++;
            }
            else{
                arrayle[indexle]=array[i];
                indexle++;
            }
        }
        Console.Write("Even array: ");
        for(int i=0;i<indexchan;i++){
            Console.Write($"{arraychan[i]} ");
        }
    

        Console.Write("Odd array: ");
        for(int i=0;i<indexle;i++){
            Console.Write($"{arrayle[i]} ");
        }
        
        
        
        
    }
}