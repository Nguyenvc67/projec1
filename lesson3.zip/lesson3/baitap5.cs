﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string num;
        
        Console.Write("Input number of element: ");
        num=Console.ReadLine();
        int inum=Convert.ToInt32(num);
        int []array=new int[inum];
        for(int i=0;i<inum;i++){
            Console.Write($"{i+1}th element: ");
            string k=Console.ReadLine();
            array[i]=Convert.ToInt32(k);
        }
        Console.Write("Input a number you want to check in array: ");
        string check;
        check=Console.ReadLine();
        int icheck=Convert.ToInt32(check);
        int dem=0;
        for(int i=0;i<inum;i++){
            if(array[i]==icheck)dem++;
        }
        if(dem==0)Console.Write($"{icheck} doesn't exist in your array !");
        else{
        Console.Write($"{icheck} frequency is: {dem}");
        
        }
        
    }
}