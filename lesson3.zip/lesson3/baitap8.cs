﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string phrase;
        string search;
        Console.Write("Input your string: ");
        phrase = Console.ReadLine();
        string []words=phrase.Split(' ');
        Console.Write("Input your search: ");
        search=Console.ReadLine();
        int dem=0;
        for(int i=0;i<words.Length;i++){
            if(words[i]==search)dem++;
        }
        Console.Write($"{search}: {dem}");
        
        
    }
}