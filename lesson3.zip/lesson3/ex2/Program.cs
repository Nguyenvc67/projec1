﻿// See https://aka.ms/new-console-template for more information
using System;
namespace intger {
class Program
{
static void Main(string[] args)
{
    int[] n= new int[10];
    Console.Write("nhap so thu nhat: ");
    n[0]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu hai: ");
    n[1]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu ba: ");
    n[2]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu tu: ");
    n[3]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu nam: ");
    n[4]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu sau: ");
    n[5]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu bay: ");
    n[6]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu tam: ");
    n[7]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu chin: ");
    n[8]=int.Parse(Console.ReadLine());
    Console.Write("nhap so thu muoi: ");
    n[9]=int.Parse(Console.ReadLine());
    int num;
        Console.Write("nhap so can tim: ");
        num=int.Parse(Console.ReadLine());
     for(int i=0;i<10;i++)
     {
        if(num==n[i])
        {
            Console.Write("n"+n[i]);
            Console.WriteLine("="+num);
        }
     }
// // Console.Write("nhap vao so nguyen:");
// // int n=int.Parse(Console.ReadLine());
// for(i=0; i< 10; i++)
// {
//     n[i]= i + 10;
// }
// for(j=0; j< 10; j++)
// Console.WriteLine("Element[{0}] = {1}", j, n[j]);
Console.ReadKey();
}
}
}

