﻿using System;

class Program{
    static void Main(string []args){
        string cs;
        string searchh;
        Console.Write("Input the string you want to consider: ");
        cs=Console.ReadLine();
        Console.Write("The string that you want to check the frequence: ");
        searchh=Console.ReadLine();
        int dem=0;
        for(int i=0;i<cs.Length;i++){
            int k=i;
            int check=0;
            for(int j=0;j<searchh.Length;j++){
                if(searchh[j]==cs[k]){
                    check++;
                    k++;
                }
            }
            if(check==searchh.Length)dem++;
        }
        Console.Write($"The substring inside the string primitive has {dem} frequence.");

    }
}