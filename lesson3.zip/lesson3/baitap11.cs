﻿using System;
using System.Text.RegularExpressions;
class Program{
    static void Main(string []args){
        Console.Write("Input email: ");
        string e=Console.ReadLine()??"";
        string pattern=@"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$";
        if(Regex.IsMatch(e, pattern, RegexOptions.IgnoreCase)){
            Console.WriteLine($"'{e}' is an email address.");
        }
        else{
            Console.WriteLine($"'{e}' is not an email address.");
        }

    }
}