﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string phrase;
        string search;
        Console.Write("Input your string: ");
        phrase = Console.ReadLine();
        char []DelimiterChar={' ',',','.',':',';','\t'};
        string []words=phrase.Split(DelimiterChar);
        Console.Write("Split your string: ");
        int dem=0;
        foreach(var word in words){
            
            dem++;
        }
        Console.Write($"Total number of word: {dem}");
        
        
        
    }
}