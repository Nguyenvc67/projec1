﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string target;
        
        Console.WriteLine ("Hello User! Please type a text: ");
        target=Console.ReadLine();
        int sum=0;
        for(int i=0;i<target.Length;i++){
            if(Char.IsDigit(target,i)){
                int k=Convert.ToInt32(new string (target[i],1));
                sum+=k;
            }
        }
        Console.WriteLine($"Sum of all digits inside a string that u just type is : {sum}");
    }
}