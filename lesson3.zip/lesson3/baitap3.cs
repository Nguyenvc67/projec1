﻿using System;

class Program{
    static void Main(string []args){
        string num;
        string num1;
        Console.WriteLine("Create an array ");
        Console.Write("How many element: ");
        num=Console.ReadLine();
        int inum=Convert.ToInt32(num);
        int []array=new int[inum];
        for(int i=0;i<inum;i++){
            Console.Write($"Input {i+1}th element: ");
            string id=Console.ReadLine();
            array[i]=Convert.ToInt32(id);
        }
        Console.WriteLine("Copy to another array and reverse .");
        int []carray=new int[inum];
        int reverse=inum-1;
        for(int i=0;i<inum;i++){
            carray[i]=array[reverse];
            reverse--;
        }
        for(int i=0;i<inum;i++){
            Console.Write($"{carray[i]} ");
        }

    
    }
}