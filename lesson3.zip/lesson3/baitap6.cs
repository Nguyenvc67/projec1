﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;

 class HelloWorld
{
     static void Main(string[] args)
    {
        string num;
        
        Console.Write("Input number of element: ");
        num=Console.ReadLine();
        int inum=Convert.ToInt32(num);
        int []array=new int[inum];
        for(int i=0;i<inum;i++){
            Console.Write($"{i+1}th element: ");
            string k=Console.ReadLine();
            array[i]=Convert.ToInt32(k);
        }
        
        for(int i=0;i<inum;i++){
        int dem=0;
        for(int j=0;j<inum;j++){
            if(array[i]==array[j])dem++;
        }
        Console.WriteLine($"{array[i]} is: {dem} times.");
        }
        
    }
}