﻿using System;

class Program{
    static void Main(string []args){
        int length=3;
        int width=4;
        int[ , ] array= new int[length, width] ;
        for(int i=0;i<length;i++){
            for(int j=0;j<width;j++){
                Random r=new Random();
                array[i, j]=r.Next(0,100);

            }
        }
        for(int i=0;i<length;i++){
            for(int j=0;j<width;j++){
                Console.Write($" {array[i, j]}");

            }
        }
        int max=0;
        for(int i=0;i<length;i++){
            for(int j=0;j<width;j++){
                if(array[i, j]>max)max=array[i, j];

            }
        }
        int min=10000;
        for(int i=0;i<length;i++){
            for(int j=0;j<width;j++){
                if(array[i, j]<min)min=array[i, j];

            }
        }
        Console.Write("\nMaximum number of this 2d array is: {0}",max);
        Console.Write("\nMinimum number of this 2d array is: {0}",min);
        
    }
}