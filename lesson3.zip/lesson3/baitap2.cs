﻿using System;
using System.Collections.Generic;
class Program{
    static void Main(string []args){
        string s;
        string k;
        int iso;
        int []array= new int[10];
        for(int i=0;i<10;i++){
            Console.Write($"Input {i}th element: ");
            k=Console.ReadLine();
            array[i]=Convert.ToInt32(k);
        }
        Console.Write("Search a number: ");
        s=Console.ReadLine();
        iso=Convert.ToInt32(s);
        int dem=0;
        for(int i=0;i<10;i++){
            if(iso==array[i]){
                Console.Write($"{array[i]} found");
                dem++;
                break;
            }
        }
        if(dem==0)Console.Write($"{iso} not found");
    }
}