﻿// See https://aka.ms/new-console-template for more information
using System;
class Program
{
static void Main(string[] args)
{
Console.WriteLine("No\tName\t\t\tBirtday\t\tHometown\tNationality\tClass\tHobby\n");
Console.WriteLine("--\t----\t\t\t-------\t\t--------\t-----------\t-----\t-----\n");
Console.WriteLine("1\tVu Cong Nguyen\t\t06/07/2023\tBac Ninh\tViennam\t\tpf1121\tTravelling\n");

}
}
