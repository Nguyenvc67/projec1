class Studen
     {
          
     }