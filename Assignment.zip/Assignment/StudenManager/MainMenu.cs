public class MainMenu
{
    public void MenuManager()
    {
        Console.WriteLine("========================================");
        Console.WriteLine(" --- VTC ACADEMY STUDENT MANAGEMENT --- ");
        Console.WriteLine("========================================");
        Console.WriteLine("1. STUDENT LIST MANAGEMENT");
        Console.WriteLine("2. CLASSES MANAGEMENT");
        Console.WriteLine("3. EXIT APPLICATION");
        Console.WriteLine("========================================");
    }
    public void MenuStuden()
    {
        Console.WriteLine("========================================");
        Console.WriteLine(" --- VTC ACADEMY STUDENT MANAGEMENT --- ");
        Console.WriteLine(" STUDENT LIST MANAGEMENT");
        Console.WriteLine("========================================");
        Console.WriteLine("1. ADD STUDENTS");
        Console.WriteLine("2. SEARCH STUDENTS");
        Console.WriteLine("3. SHOW ALL STUDENTS");
        Console.WriteLine("4. BACK TO MAIN MENU");
        Console.WriteLine("========================================");
    }
    public void MenuClass()
    {
        Console.WriteLine("========================================");
        Console.WriteLine(" --- VTC ACADEMY STUDENT MANAGEMENT --- ");
        Console.WriteLine(" CLASSES MANAGEMENT");
        Console.WriteLine("========================================");
        Console.WriteLine("1. ADD CLASS");
        Console.WriteLine("2. STUDYING CLASSES");
        Console.WriteLine("3. COMPLETED CLASSES");
        Console.WriteLine("4. CLOSED CLASSES");
        Console.WriteLine("5. ALL CLASSES");
        Console.WriteLine("5. BACK TO MAIN MENU");
        Console.WriteLine("========================================");
    }
}